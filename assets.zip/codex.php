<?php
include "components/header.php";
include "components/navigation.php";
?>


<div style="overflow: hidden;padding-bottom:10%;">
    <div class="row ">
        <div class="col-md-12  ">
            <div class="about-head">KODEKS ETIKE</div>
        </div>
    </div>

    <div class="row">
        <div class="col-md-5 col-lg-5 col-3 "></div>
        <div class="col-md-2 col-lg-2 col-6  ">
            <a href="https://www.hgk.hr/kodeks-etike" target="blank"><img  src="assets/images/povelja-kodeks-etike.png" alt=""></a>
        </div>
        <div class="col-md-5 col-lg-5 col-3 "></div>
    </div>
    <div class="row">
        <div class="col-md-4 col-lg-4 col-3 "></div>
        <div class="col-md-4 col-lg-4 col-6  "><br>
            <p class="about-par"><a class="most-used-link" href="assets/pdfs/PoveljaKodeksEtike.pdf" target="_blank">IMAVES povelja kodeks etike</a></p>
        </div>

        <div class="col-md-4 col-lg-4 col-3 "></div>
    </div>



</div>


<?php
include "components/footer.php";
?>