<?php
include "components/header.php";
include "components/navigation-en.php";
?>


<div style="overflow: hidden;padding-bottom:10%;">
    <div class="row ">
        <div class="col-md-12  ">
            <div class="about-head">ISO CERTIFICATE</div>
        </div>
    </div>

    <div class="row">
        <div class="col-md-5 col-lg-5 col-1 "></div>
        <div class="col-md-2 col-lg-2 col-10  ">
            <a href="https://www.tuv-nord.com/hr/hr/usluge/certifikacija-sustava/iso-9001/" target="blank"><img  src="assets/images/iso.png" alt=""></a>
        </div>
        <div class="col-md-5 col-lg-5 col-1 "></div>
    </div>
    <div class="row">
        <div class="col-md-4 col-lg-4 col-3 "></div>
        <div class="col-md-4 col-lg-4 col-6  "><br>
            <p class="about-par"><a class="most-used-link" href="assets/pdfs/iso-certifikat-eng.pdf" target="_blank">IMAVES ISO certificate</a></p>
        </div>

        <div class="col-md-4 col-lg-4 col-3 "></div>
    </div>



</div>


<?php
include "components/footer-en.php";
?>