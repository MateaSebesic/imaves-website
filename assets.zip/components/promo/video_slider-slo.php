<br>
<br>


<div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
<ol class="carousel-indicators">
        <li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
        <li data-target="#carouselExampleIndicators" data-slide-to="1"></li>
        
<!--        <li data-target="#carouselExampleIndicators" data-slide-to="4"></li>-->
    </ol>
    
    <div class="carousel-inner" style= "padding-left:2% padding-rightt:2%" >

        <div class="carousel-item active" data-interval="100000"style="background-color: rgba(243,146,0, 0.4); text-align:center;">
            <iframe width="560" height="315" style= "padding-top:2%" src="https://www.youtube.com/embed/pLirVzHq6L4" frameborder="0"
                allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                allowfullscreen></iframe>
            <p class="most-used-par1-4me" style= "padding-left:5% ;padding-right:5%" >Kot delodajalec ste se zagotovo srečali s tehnološkimi šibkostmi orodij za podporo uporabnikom. Primeri tega so dolgo čakanje za obdelavo večje količine zahtevkov, marsikateri procesi niso avtomatizirani in zahtevajo veliko korakov do rešitve, težko je priti do pravih informacij zaradi slabega filtriranja podatkov, za različne zahtevke je potrebno uporabljati več orodij namesto da bi vse bilo na enem mestu.<br><br> Ključni cilj je celovita uspešnost, ne zgolj samo hitrost obravnave velike količine podatkov in čas odzivnosti, ampak tudi učinkovitost uporabniškega vmesnika.<br><br>
            </p>

        </div>
        <div class="carousel-item" data-interval="100000" style="background-color: rgba(89,164,217,0.5); text-align:center;">
            <iframe width="560" height="315" style= "padding-top:2%" src="https://www.youtube.com/embed/u35l8bRm6kk" frameborder="0"
                allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                allowfullscreen></iframe>
            <p class="most-used-par1-4me" style= "padding-left:5% ;padding-right:5%" >Danes se organizacije opirajo na zunanje ponudnike storitev (outsourcing), da bi se lahko čim bolje posvetile jedru svojega lastnega poslovanja in kot celoto ponudile kvalitetno storitev končni stranki. Zunanji ponudnik, oziroma podizvajalec, ki ga organizacija najame, ima najverjetneje lastna orodja za upravljanje s svojimi storitvami. Enako ima lastna orodja tudi organizacija. Problem se pojavi, kadar ta orodja ne podpirajo medsebojnega sodelovanja zunanjega podizvajalca in organizacije. <br><br>S 4me so takšni scenariji preteklost. 4me predstavlja brezhibno in varno komunikacijo – ne samo znotraj vaše organizacije in z vašimi strankami, ampak tudi med različnimi ponudniki zunanjih storitev. 4me podpira SIAM model; omogoča specializacijo, produktivnost in brezhibno komunikacijo med vsemi sodelujočimi v procesu poslovanja.<br></p>
        </div>

    </div>
    <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev" style="text-align: left ;padding-bottom:20%">
        <span class="carousel-control-prev-icon" aria-hidden="true" style="background-color: orange;"></span>
        <span class="sr-only">Previous</span>
    </a>
    <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next"  style="text-align: right ;padding-bottom:20%">
        <span class="carousel-control-next-icon" aria-hidden="true" style="background-color: orange;"></span>
        <span class="sr-only">Next</span>
    </a>
</div>

<br>
<br>