<?php
include "components/header.php";
include "components/navigation-en.php";
?>
<div style="overflow: hidden;">
    <div class="row " >
        <div class="col-md-4  col-lg-4 col-sm-12 d-none d-lg-block"><img class="header-img" style="width: inherit;"
                src="assets/images/background-registered.png" alt="">
            <div class="centered most-used-head-2">TECHNICAL SUPPORT</div>

        </div>
        <div class="col-md-1 col-lg-1 col-sm-1 d-none d-lg-block">

        </div>
        <div class="col-md-12 col-lg-5 col-sm-12 header-img reg-header" >
            <div class="registered-form">


                <p class="registered-head">
                    REGISTERED USERS
                </p>
                <div class="registered-button-div">
                <a target="_blank" href="https://imaves.4me.com/" class="registered-button "><span
                        class="registered-button-text">LOGIN TO IMAVES SERVICE DESK</span></a>
                </div>
                
                <p class="registered-par1">
                    If you are having any trouble with login or sending request, please send an e-mail at: <a
                        href="mailto:info@imaves.hr?subject=Registered user problem"
                        class="registered-link">info@imaves.hr</a></p>


            </div>
        </div>
        <div class="col-md-2 col-lg-2 col-sm-1 d-none d-lg-block">

        </div>
    </div>
</div>




<?php
include "components/footer-en.php";
?>